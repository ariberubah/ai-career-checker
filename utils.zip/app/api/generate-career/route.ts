// app/api/generate-career/route.ts

import { NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";

// Inisialisasi Gemini API
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function POST(req: Request) {
  try {
    const stats = await req.json();

    const prompt = `
Kamu adalah asisten karier.
Berdasarkan statistik berikut, tentukan pekerjaan paling cocok, berikan nama "class", dan jelaskan alasannya.
Balas dalam format JSON:
{
  "name": "Nama Class",
  "desc": "Deskripsi singkat mengapa cocok",
  "recommended_fields": ["Bidang 1", "Bidang 2", "Bidang 3"]
}

Statistik pengguna:
${JSON.stringify(stats, null, 2)}
    `;

    // ✅ GUNAKAN model yang masih valid
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp", // model aktif per dokumentasi terbaru
    });

    // ✅ Gunakan struktur generateContent sesuai dokumentasi quickstart
    const result = await model.generateContent({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
    });

    const text = result.response.text();

    // Parsing aman kalau Gemini balas aneh
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const parsed = jsonMatch
      ? JSON.parse(jsonMatch[0])
      : {
          name: "Undefined",
          desc: "AI gagal menentukan karier yang cocok.",
          recommended_fields: [],
        };

    return NextResponse.json(parsed);
  } catch (err) {
    console.error("Error di /api/generate-career:", err);
    return NextResponse.json(
      { error: "Gagal memproses karier, coba lagi nanti." },
      { status: 500 }
    );
  }
}

// Opsional: tolak method selain POST
export async function GET() {
  return NextResponse.json(
    { error: "Gunakan POST, bukan GET." },
    { status: 405 }
  );
}
