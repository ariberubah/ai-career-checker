export const mentalQuestions = [
  { id: 'focus', label: 'Seberapa mudah kamu mempertahankan fokus dalam waktu lama?' },
  { id: 'stress_resistance', label: 'Seberapa tenang kamu menghadapi tekanan atau situasi tak terduga?' },
  { id: 'growth_mindset', label: 'Seberapa sering kamu melihat kesalahan sebagai peluang belajar?' },
  { id: 'emotional_awareness', label: 'Seberapa peka kamu mengenali dan mengatur emosimu sendiri?' },
  { id: 'motivation', label: 'Seberapa kuat keinginanmu untuk terus berkembang meskipun tidak ada dorongan dari luar?' },
]
