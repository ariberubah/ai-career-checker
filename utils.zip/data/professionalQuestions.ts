export const professionalQuestions = [
  { id: 'leadership', label: 'Seberapa nyaman kamu mengambil keputusan untuk tim atau kelompok?' },
  { id: 'adaptability', label: 'Seberapa cepat kamu bisa menyesuaikan diri saat terjadi perubahan besar?' },
  { id: 'communication', label: 'Seberapa baik kamu menjelaskan ide ke orang lain?' },
  { id: 'problem_solving', label: 'Seberapa sering kamu menemukan solusi ketika hal tak berjalan sesuai rencana?' },
  { id: 'organization', label: 'Seberapa teratur kamu dalam mengatur pekerjaan dan prioritas?' },
]
