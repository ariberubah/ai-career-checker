export const coreQuestions = [
  { id: 'intelligence', label: 'Seberapa cepat kamu memahami konsep baru atau ide kompleks?' },
  { id: 'creativity', label: 'Seberapa sering kamu menemukan cara unik untuk memecahkan masalah?' },
  { id: 'discipline', label: 'Seberapa konsisten kamu menyelesaikan sesuatu meskipun sedang tidak mood?' },
  { id: 'charisma', label: 'Seberapa mudah kamu membuat orang lain merasa nyaman saat berinteraksi?' },
  { id: 'luck', label: 'Seberapa sering hal-hal tak terduga berjalan sesuai keinginanmu?' },
]
